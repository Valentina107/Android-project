package com.example.interpretecomandiremotisms;

public class ServiceCommunicator {
}
