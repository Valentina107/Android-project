package com.example.interpretecomandiremotisms.utility;

public class Controls {

    /**
     * Verifica se il numero di telefono ha esattamente 10 cifre
     *
     * @param numberPhone numero di telefono
     * @return true se il numero di telefono ha 10 cifre, false altrimenti
     */
    public static boolean checkNumberPhone(String numberPhone) {
        return numberPhone.length() == 10;
    }

}
