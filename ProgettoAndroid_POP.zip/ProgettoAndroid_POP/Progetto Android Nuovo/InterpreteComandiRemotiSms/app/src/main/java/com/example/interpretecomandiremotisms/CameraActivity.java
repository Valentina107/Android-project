package com.example.interpretecomandiremotisms;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class CameraActivity extends AppCompatActivity {

    //private static final int Camera_Request=100;
    private Button scattaFoto;
    private ImageView imgCamera;
    ActivityResultLauncher<Intent> activityResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        scattaFoto = findViewById(R.id.btnFoto);
        imgCamera = findViewById(R.id.imgView);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {

                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {

                            Intent data = result.getData();
                            Bitmap bp = (Bitmap) data.getExtras().get("data");
                            imgCamera.setImageBitmap(bp);
                        }
                    }

                });


        scattaFoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (checkPermissions()) {
                    Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    try {
                        activityResultLauncher.launch(intentCamera);

                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(CameraActivity.this, "Azione non supportata",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else {
                    ActivityCompat.requestPermissions(CameraActivity.this, new String[]{
                            Manifest.permission.CAMERA,
                    }, 1);

                }

            }
        });
    }


    private boolean checkPermissions() {

        int first = ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CAMERA);

        return first == PackageManager.PERMISSION_GRANTED;

    }



    //Serve per chiudere l'app
    @Override
    public void onBackPressed(){
        this.finish();

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();


        if(id==R.id.scatafoto) {
            Intent i = new Intent(CameraActivity.this, CameraActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.audio) {
            Intent i = new Intent(CameraActivity.this, AudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.inviafoto) {
            Intent i = new Intent(CameraActivity.this, InviaFotoActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.riproduzioneaudio) {
            Intent i = new Intent(CameraActivity.this, RiproduzioneAudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}


