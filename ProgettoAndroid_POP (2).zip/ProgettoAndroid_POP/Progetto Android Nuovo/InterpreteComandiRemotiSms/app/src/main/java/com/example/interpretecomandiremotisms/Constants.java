package com.example.interpretecomandiremotisms;

public class Constants {

    public static final String takePhoto="Scatta foto";
    public static final String recSound="Registra suono";
    public static final String sendPhoto="Invia foto";
    public static final String playSound="Riproduci audio";
    public static final String errorSmsCmd="Comando non previsto";

}
