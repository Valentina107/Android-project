package com.example.interpretecomandiremotisms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class AudioActivity extends AppCompatActivity {

    private Button play, rec;
    private MediaRecorder registratore = null;
    private MediaPlayer riproduttore = null;
    private static String nomeFileAudio = null;

    /*servono per stabilire quando uno dei due comp.del registratore sta
     *funzionando; ovvero, per reimpostare i tasti durante il loro utilizzo */
    private boolean ascoltando = false;
    private boolean registrando = false;

    @Override
    protected void onCreate(Bundle args) {
        super.onCreate(args);
        setContentView(R.layout.activity_audio);

        Button rec = findViewById(R.id.btnRec);
        Button play = findViewById(R.id.btnPlay);

        nomeFileAudio = Environment.getExternalStorageDirectory().getAbsolutePath()+"/"+"Download/registrazione.mp3";


        rec.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (checkPermissions()) {
                    if (registrando) {
                        // Interrompe la registrazione dell' audio e cambia il testo
                        fermaRegistrazione();
                        rec.setText("Registra");

                    } else {
                        // Inizia la registrazione dell' audio e cambia il testo sul bottone
                        registra();
                        rec.setText("Ferma registrazione");

                    }
                    registrando = !registrando;

                } else {
                    ActivityCompat.requestPermissions(AudioActivity.this, new String[] {
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    }, 1);

                }

            }

        });


        play.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (ascoltando) {

                    // serve ad interrompere la riproduzione dell' audio e cambiare il testo sul bottone
                    fermaRiproduzione();
                    play.setText("Ascolta");

                } else {

                    // serve ad iniziare la riproduzione dell'audio e a cambiare il testo sul bottone
                    riproduci();
                    play.setText("Ferma");
                }

                ascoltando = !ascoltando;

            }

        });


    }


    private boolean checkPermissions() {

        int first = ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.RECORD_AUDIO);

        int second = ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE);

        int third = ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE);

        return first == PackageManager.PERMISSION_GRANTED &&
                second == PackageManager.PERMISSION_GRANTED &&
                third == PackageManager.PERMISSION_GRANTED;

    }



    //funzione che gestisce la riproduzione dell'audio
    private void riproduci() {

        riproduttore = new MediaPlayer();
        try {

            riproduttore.setDataSource(nomeFileAudio);
            riproduttore.prepare();
            riproduttore.start();

        } catch (IOException e) {

            System.out.println(e);

        }

    }

    private void fermaRiproduzione() {

        riproduttore.release();
        riproduttore = null;

    }




    //registra e salva l' audio nel file "registrazione.3gp"
    private void registra() {

        registratore = new MediaRecorder();
        registratore.setAudioSource(MediaRecorder.AudioSource.MIC);
        registratore.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        registratore.setOutputFile(nomeFileAudio);
        registratore.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);

        try {

            registratore.prepare();
            registratore.start();
            Toast.makeText(AudioActivity.this, "Registrazione iniziata", Toast.LENGTH_SHORT).show();

        } catch (IOException e) {
            System.out.println(e);

        }

    }



    private void fermaRegistrazione() {

        try {
            registratore.stop();
            registratore.release();
            registratore = null;
            Toast.makeText(AudioActivity.this, R.string.error_endRecSound, Toast.LENGTH_SHORT).show();

        } catch (Exception e) {

            System.out.println(e);

        }
    }



    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();

        if(id==R.id.scatafoto) {
            Intent i = new Intent(AudioActivity.this, CameraActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.audio) {
            Intent i = new Intent(AudioActivity.this, AudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.inviafoto) {
            Intent i = new Intent(AudioActivity.this, InviaFotoActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.riproduzioneaudio) {
            Intent i = new Intent(AudioActivity.this, RiproduzioneAudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}

