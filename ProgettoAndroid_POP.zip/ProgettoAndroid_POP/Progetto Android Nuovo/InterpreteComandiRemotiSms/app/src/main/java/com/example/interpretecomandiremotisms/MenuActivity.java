package com.example.interpretecomandiremotisms;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.graphics.Camera;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.SEND_SMS,
        };

        ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);
        Intent serviceIntent = new Intent(this, ServiceCommunicator.class);
        startService(serviceIntent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id=item.getItemId();


        if(id==R.id.scatafoto) {
            Intent i = new Intent(MenuActivity.this, CameraActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.audio) {
            Intent i = new Intent(MenuActivity.this, AudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.inviafoto) {
            Intent i = new Intent(MenuActivity.this, InviaFotoActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.riproduzioneaudio) {
            Intent i = new Intent(MenuActivity.this, RiproduzioneAudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}