package com.example.interpretecomandiremotisms;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class InviaFotoActivity extends AppCompatActivity {

    ImageView foto;
    Button inviaFoto, selezionaFoto;
    ActivityResultLauncher<Intent> activityResultLauncher;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invia_foto);

        foto = findViewById(R.id.image);
        inviaFoto = findViewById(R.id.btnSend);
        selezionaFoto = findViewById(R.id.btnFoto);



        //classe di avvio  dell'attivita

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {  //se abbiamo un file
                            Intent data= result.getData();
                            Uri selezionaFoto = data.getData();
                            foto.setImageURI(selezionaFoto );

                        }
                    }
                }

        );


        selezionaFoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent data=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                data.setType("image/*");
                data= Intent.createChooser(data,"Choose a file");
                activityResultLauncher.launch(data);

            }
        });


        inviaFoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent smsIntent = new Intent(Intent.ACTION_SEND);
                smsIntent.putExtra("address", "3245848659");
                smsIntent.putExtra("sms_body", "This is the text mms");
                smsIntent.putExtra(Intent.EXTRA_STREAM,"file:/" + foto);
                smsIntent.setType("image/png");
                startActivity(smsIntent);


            }
        });


    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();


        if(id==R.id.scatafoto) {
            Intent i = new Intent(InviaFotoActivity.this, CameraActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.audio) {
            Intent i = new Intent(InviaFotoActivity.this, AudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.inviafoto) {
            Intent i = new Intent(InviaFotoActivity.this, InviaFotoActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.riproduzioneaudio) {
            Intent i = new Intent(InviaFotoActivity.this, RiproduzioneAudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
