package com.example.interpretecomandiremotisms;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class RiproduzioneAudioActivity extends AppCompatActivity {

    private MediaPlayer riproduttore;
    Button selezionaAudio, riproduciAudio ;
    TextView textview;
    ActivityResultLauncher<Intent> activityResultLauncher;
    String nomeFileAudio = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riproduzione_audio);

        selezionaAudio = findViewById(R.id.btnAudio);
        riproduciAudio = findViewById(R.id.btnPlay);
        textview = findViewById(R.id.textView);



        //codice per selezionare un file audio
        selezionaAudio.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intentAudio = new Intent(Intent.ACTION_GET_CONTENT);
                intentAudio.setType("audio/*");
                intentAudio = Intent.createChooser(intentAudio, "Select Audio");
                activityResultLauncher.launch(intentAudio);

            }
        });


        //Recupera il file dei risultati
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {

                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {  //se abbiamo un file
                            Intent audio = result.getData();
                            //usiamo l'URI per ottenere il percorso del file
                            Uri audioUri = audio.getData();
                            createMediaPlayer(audioUri);

                        }
                    }
                });



        riproduciAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (riproduttore != null) {
                    if (riproduttore.isPlaying()) {
                        riproduttore.pause();
                        riproduciAudio.setText("PLAY");

                    } else {
                        riproduttore.start();
                        riproduciAudio.setText("PAUSE");


                    }
                }
            }
        });

        riproduciAudio.setEnabled(false);

    }



    public void createMediaPlayer(Uri uri){
        riproduttore = new MediaPlayer();
        riproduttore.setAudioAttributes(
                new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build());

        try {
            riproduttore.setDataSource(getApplicationContext(), uri);
            riproduttore.prepare();

            textview.setText(getNameFromUri(uri));
            riproduciAudio.setEnabled(true);

            riproduttore.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    releaseMediaPlayer();
                }
            });
        } catch (IOException e){
            textview.setText(e.toString());
        }
    }

    /*Il metdodo onDestroy serve quando l'untente esce dall'app
     * mentre la canzzone è in riproduzione*/
    @Override
    protected void onDestroy() {
        super.onDestroy();
        releaseMediaPlayer();
    }



    //Metodo per ottenere il nome del file
    @SuppressLint("Range")
    public String getNameFromUri(Uri uri){
        String fileName = "";
        Cursor cursor = null;
        cursor = getContentResolver().query(uri, new String[]{
                MediaStore.Images.ImageColumns.DISPLAY_NAME
        }, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            fileName = cursor.getString(cursor.getColumnIndex(MediaStore.Images.ImageColumns.DISPLAY_NAME));
        }

        if (cursor != null) {
            cursor.close();
        }
        return fileName;
    }


    public void releaseMediaPlayer(){
        if (riproduttore != null) {
            riproduttore.release();
            riproduttore = null;
        }
        riproduciAudio.setEnabled(false);
        textview.setText("TITLE");
    }





    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();


        if(id==R.id.scatafoto) {
            Intent i = new Intent(RiproduzioneAudioActivity.this, CameraActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.audio) {
            Intent i = new Intent(RiproduzioneAudioActivity.this, AudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.inviafoto) {
            Intent i = new Intent(RiproduzioneAudioActivity.this, InviaFotoActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        if(id==R.id.riproduzioneaudio) {
            Intent i = new Intent(RiproduzioneAudioActivity.this, RiproduzioneAudioActivity.class);
            startActivity(i);
            finish();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}