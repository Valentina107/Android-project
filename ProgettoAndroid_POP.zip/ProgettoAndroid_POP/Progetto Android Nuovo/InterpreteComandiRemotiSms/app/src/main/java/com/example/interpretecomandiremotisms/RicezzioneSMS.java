package com.example.interpretecomandiremotisms;

import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import com.example.interpretecomandiremotisms.utility.Controls;

public class RicezzioneSMS extends BroadcastReceiver {

    private static final String TAG =
            RicezzioneSMS.class.getSimpleName();
    public static final String pdu_type = "pdus";

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        SmsMessage[] msgs;
        String strNumero = "";
        String strTesto = "";

        String[] numeroTelefoniAutorizzati = {"3246765890", "6505551213", "3245848656", "3246748982"};
        System.out.println("ciao");
        String format = bundle.getString("format");

        //  Recupera il messaggio ricevuto.
        Object[] pdus = (Object[]) bundle.get("pdus");

        if (pdus != null) {
            // Controlla la versione di Android.
            boolean isVersionM =
                    (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M);

            // Riempire la matrice msgs.
            msgs = new SmsMessage[pdus.length];
            for (int i = 0; i < msgs.length; i++) {
                // Controlla la versione di Android e usa createFromPdu appropriato.
                if (isVersionM) {
                    // If Android version M or newer:
                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i], format);
                } else {
                    // If Android version L or older:
                    msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                }

                // Crea il messaggio da mostrare.
                strNumero = msgs[i].getOriginatingAddress();
                strTesto = msgs[i].getMessageBody() + "\n";

                System.out.println(strNumero);
                System.out.println(strTesto);

                if(!Controls.checkNumberPhone(strNumero)){
                    Toast.makeText(context, R.string.error_numberPhone, Toast.LENGTH_LONG).show();
                }

                boolean flag = false;
                for (int j = 0; j < numeroTelefoniAutorizzati.length; j++) {
                    if (strNumero.equalsIgnoreCase(numeroTelefoniAutorizzati[j])) {
                        flag = true;
                    }
                }


                if (flag) {
                    String[] splitsString = strTesto.split(System.lineSeparator());

                    String firstString = splitsString[0];

                    switch (firstString) {
                        case Constants.takePhoto: {
                            //Dopo aver cambiato l'attività del display e aperto la fotocamera
                            Intent intento = new Intent(context, CameraActivity.class);
                            intento.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intento);
                        }
                        break;
                        case Constants.recSound: {
                            Intent intento = new Intent(context, AudioActivity.class);
                            intento.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intento);
                        }
                        break;
                        case Constants.sendPhoto: {
                            Intent intento = new Intent(context, InviaFotoActivity.class);
                            intento.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intento);
                        }
                        break;
                        case Constants.playSound: {
                            Intent intento = new Intent(context, RiproduzioneAudioActivity.class);
                            intento.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            context.startActivity(intento);
                        }
                        break;
                        default:
                            Toast.makeText(context, Constants.errorSmsCmd, Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }
}
